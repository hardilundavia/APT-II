﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Xml;

namespace WebApplication3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connetionString = null;
            SqlConnection connection;
            SqlCommand command;
            SqlDataAdapter adpter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            XmlReader xmlFile;
            string sql = null;

            string EmployeeId = null;
            string EmployeeName = null;
            double EmployeeSalary = 0;

            connetionString = "Data Source=(localdb)\\ProjectsV13;Initial Catalog=Emp;Integrated Security=True";

            connection = new SqlConnection(connetionString);

            xmlFile = XmlReader.Create("D:\\APT-II038\\WebApplication3\\WebApplication3\\XMLFile1.xml", new XmlReaderSettings());
            ds.ReadXml(xmlFile);
            int i = 0;
            connection.Open();
            for (i = 0; i < ds.Tables[0].Rows.Count - 1; i++)
            {
                EmployeeId = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                EmployeeName = ds.Tables[0].Rows[i].ItemArray[1].ToString();
                EmployeeSalary = Convert.ToDouble(ds.Tables[0].Rows[i].ItemArray[2]);
                sql = "insert into employee values('" + EmployeeId + "','" + EmployeeName + "'," + EmployeeSalary + ")";
                command = new SqlCommand(sql, connection);
                adpter.InsertCommand = command;
                adpter.InsertCommand.ExecuteNonQuery();
                Response.Write("Done .. ");
            }
            connection.Close();
           
        }
    }
}